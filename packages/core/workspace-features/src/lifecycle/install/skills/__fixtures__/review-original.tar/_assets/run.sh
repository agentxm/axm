#!/bin/sh
echo shared
