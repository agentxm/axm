# Offline native serialization comparison disposition

This is offline artifact analysis, not test execution, a CLI capture, a receiver query, or a fresh native-target audit. It applies the shared comparison method at clean revision `4fa487526f17031a8ef8f399154a00412e718e93` to four original failed comparisons. Those reports and their verdicts remain unchanged. Byte equivalence and complete attribution remain unproven.

The input archive is the repository artifact `benchmarks/evidence/local-observability/captures/run-06-remaining-195-2cf3580d3.tar.gz`, SHA-256 `7a1ab581216ce913dfaf48818cae637a71bc6caffc5c34ae30342ce33f402603`. Its original report member is `runs/run-06-remaining-195-2cf3580d3/report.json`. Its four relevant payload trees are under `reserved/typed/subagents/install`, `reserved/typed/knowledge/install`, `reserved/typed/packs/install`, and `reserved/typed/knowledge/new`. The original report's `samples/preflight/<case>/...` paths map to those `reserved/<case>/...` members. Each consumed archive member's stored and decompressed hashes appear in `dispositions.json`; `extraction-manifest.json` records the extracted member bytes/hashes.

To reproduce, use a clean checkout of the method revision with the repository's pinned tools and built workspace dependencies. Copy `consolidate.ts` into a fresh temporary directory, create `repo` and `node_modules` symlinks there to that checkout and its `node_modules`, and extract the selected archive into an `extracted` directory. No private original `/tmp` paths are required. Then run from the checkout:

```sh
mise exec -- bun "$ANALYSIS/consolidate.ts" "$ANALYSIS/extracted" "$ANALYSIS/dispositions.json"
```

The script refuses a different/dirty method checkout, archive hash mismatch, changed original report, missing proof, changed product comparisons, unreproduced full work digest, unreproduced validated inspection, or shared-guard rejection. It only writes inside the analysis directory. It validates copied receipt documents through the public schema reader and revalidates stored receiver payloads through the public inspector, without contacting Seq. Native metadata is reused from the original independent audit, matched back to exact receipt fields and approved projection markers. Historical removed scratch identities stay explicitly not post-stat verified.

`execution.stdout` and `execution.stderr` retain the successful invocation output. `*.attempt1` retain an initial offline path-resolution failure: this older archive uses `reserved/` payload paths, not the newer `runs/.../samples/` layout. The corrected mapping is explicit in the script and sidecar. No CLI workload or receiver query occurred on either attempt.

The final-field width envelope is conservative comparison eligibility, not a bound on intermediate writes or proof attributing every mixed-owner byte difference. Original scalar widths, exact byte rows, complete work digests, coverage, owner dimensions, and source/binary/harness identities remain retained. This result establishes no repeated timing/RSS qualification.
