# Shared local-observability evidence

This bounded retention bundle contains existing successful shared evidence. It does not execute new checks, certify the final integrated revision, or claim isolated repeated elapsed/RSS qualification. Original failures deliberately exercised by the successful suites remain failures in their raw inspection outputs.

## Claims

| Claim | Source | Existing result | Evidence |
| --- | --- | --- | --- |
| seq-six-case | `08befbe1662033dc2faab44bc2ace3c900a23578` | 6/6 tests passed | [logs/observability-final-seq-suite.log](logs/observability-final-seq-suite.log), [seq/worktree-isolation-NurZvD](seq/worktree-isolation-NurZvD), [seq/identity-joOdNf](seq/identity-joOdNf), [seq/body-hold-WACoyj](seq/body-hold-WACoyj), [seq/dropped-batch-LVeQr5](seq/dropped-batch-LVeQr5), [seq/collector-failure-SZKIwR](seq/collector-failure-SZKIwR), [seq/forced-kill-RWN96b](seq/forced-kill-RWN96b) |
| authenticated-seq | `b95373deb7742c3da164c9a4c3b6057e6757306f` | Readiness passed; selected source/compiled summary/detail identity case passed | [authenticated-readiness](authenticated-readiness), [seq/identity-kU7byI](seq/identity-kU7byI) |
| shutdown | `08befbe1662033dc2faab44bc2ace3c900a23578` | Reject 290.053388ms; stall 289.222285ms; both below existing 500ms bound | [metadata/shutdown-evaluation.json](metadata/shutdown-evaluation.json), [seq/collector-failure-SZKIwR](seq/collector-failure-SZKIwR) |
| native-platforms | `99856a289d1f416d4f59a7e6b26d18d76250b4f5` | Linux x64 actual casefold and Windows owner/E2E checks passed; retained metadata records ARM64 and both macOS host-step success | [platform](platform) |
| cache-prune-owners | `2cf3580d33c4a676697a80d222677f8ad59e3579` | 17 cache-owner, 11 serialized bridge, 28 method checks passed; type/lint passed | [owners/observability-cache-prune-owner3.log](owners/observability-cache-prune-owner3.log), [owners/observability-cache-prune-bridge.log](owners/observability-cache-prune-bridge.log), [owners/observability-cache-prune-method.log](owners/observability-cache-prune-method.log), [owners/observability-cache-prune-checks.log](owners/observability-cache-prune-checks.log) |
| knowledge-receipt-byte-owners | `4d8344c40f581cce18626e77299abf090dba96ee` | 21 combined owner/handler checks, 12 final handler checks, 8 receipt fixture checks passed; corrected typecheck passed | [owners/observability-prepared-receipt-tests.log](owners/observability-prepared-receipt-tests.log), [owners/observability-knowledge-and-byte-owner.log](owners/observability-knowledge-and-byte-owner.log), [owners/observability-knowledge-handler2.log](owners/observability-knowledge-handler2.log), [owners/observability-knowledge-typecheck2.log](owners/observability-knowledge-typecheck2.log) |

## seq-six-case

Command: `pnpm exec nx run cli-e2e:e2e-tracing`

Actual source/compiled identity, concurrent linked worktrees, body hold, polling/acknowledged lost batch, rejecting/stalled collector isolation, killed unfinished process; exact receipts, retrievals, independent oracles and negative inspection outputs retained.

Limits: Executed historical clean revision; no claim of final integration or repeated overhead. Failure scenarios intentionally lack complete delivery. Suite reused 24/29 input-bound prerequisite tasks.

## authenticated-seq

Command: `pnpm run seq:verify; pnpm exec nx run cli-e2e:e2e-tracing with authenticated identity case selected (exact forwarded filter in log)`

Authenticated query readiness and four actual source/compiled captures with exact raw receipt/retrieval/work expectations.

Limits: Readiness standalone temporary receipt/raw retrieval were deleted by the published workflow EXIT trap; readiness.log retains successful parsed inspection and trace ID. Raw four-capture identity evidence remains available. Container data, process snapshots and credentials excluded.

## shutdown

Command: `Same six-case suite; independent relay cleanup observations`

Observed conservative cleanup upper bounds and product outcome preservation under rejection/stall.

Limits: Contended VM; not isolated repeated elapsed/RSS qualification.

## native-platforms

Command: `GitHub CI 43364797814; job commands retained in public-projection logs and step metadata`

Actual hosted Linux/Windows command assertions plus original GitHub job/step metadata for supported native hosts.

Limits: Linux/Windows log projections explicitly omit unrelated remote inventory and replace coordination branch labels. Original hashes/line maps retained; exact raw logs remain local outside archive. macOS/ARM64 individual stdout logs were not supplied; step status metadata is retained. Two Windows platform-inapplicable skips remain skips.

## cache-prune-owners

Command: `pnpm exec nx run registry-client:test --args=archive-cache; pnpm exec nx run cli:test --args="local-tracing-reconciles-work.test.ts local-tracing-describes-operation-work.spec.ts"; pnpm exec nx run axm:test --args=observability-benchmark.test.ts; affected type/lint checkpoint`

Real scan inventory/stat ownership, bounded serializer/privacy/owner admission and strict automatic-maintenance comparison controls.

Limits: Owner logs record command/output but do not independently embed a source manifest; revision association follows the recorded clean checkpoint and retained immutable source. Not an assembled scaling capture.

## knowledge-receipt-byte-owners

Command: `pnpm exec nx run cli:test --args="src/cli-runtime/local-tracing-reconciles-work.test.ts src/root/knowledge/json-output.test.ts"; pnpm exec nx run cli:test --args=src/root/knowledge/json-output.test.ts; pnpm exec nx run axm:test --args=observability-receipt-fixture.test.ts; corrected cli typecheck`

Native receipt-byte work reconciles independently, Knowledge construction/handlers preserve meaningful observations, and only exact independently validated preparation identities carry into comparison. The receipt target also reuses 16 passing integration-hook controls including a real blocked main push.

Limits: Counts overlap; do not add them as unique tests. Logs predate the coherent commit and lack embedded per-run source manifests; immutable source is retained for matching, not falsely called contemporaneous source attestation. Does not certify four unresolved cross-run byte-parity cases.

## Retention and provenance

See [claim-index.json](claim-index.json) for trace IDs, raw retrieval timestamps, exact build identities, immutable Git source blobs and excluded artifacts. Both normal and authenticated source/compiled fixture accounts are synthetic and independently declared in the retained immutable loopback server source. Product credential stores are represented only by file hashes; no whole homes or credential files are included.

The platform `.public-projection.log` files are explicitly projected, never labeled raw. [redaction-manifest.json](redaction-manifest.json) records original/projected SHA-256 and every omitted/replaced original line number. Exact original CI logs remain locally outside this public archive. Verification commands, commit SHA, assertions, native metadata and result statuses are preserved.

The readiness workflow intentionally deletes its temporary raw receipt and query files; its stdout retains parsed inspection with exact trace identity. The four authenticated identity captures retain independent raw receipts and receiver trees. Individual macOS/ARM64 stdout logs were not supplied; original GitHub job/step status metadata is retained. Owner logs identify commands/results, but do not independently embed a contemporaneous source manifest; immutable checkpoint source is associated honestly, without inventing per-run source attestation.

## Integrity

Every retained file is indexed by SHA-256. `SHA256SUMS` covers all other archive members. The enclosing ordinary gzip/tar archive uses sorted relative paths, fixed file modes, zero timestamps, uid/gid 0 and empty user/group names. Its byte-for-byte deterministic rebuild and complete member readback are recorded in the external archive verification sidecar. No credentials, unrelated historical runs, Seq container data, host/process snapshots, or binary payloads are included.
