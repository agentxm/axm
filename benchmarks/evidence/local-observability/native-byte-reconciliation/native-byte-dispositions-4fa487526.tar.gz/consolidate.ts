/** Offline retained-artifact analysis only. No CLI, Seq query, or current native-target verification. */
import * as fs from "node:fs";
import * as path from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";
import { gunzipSync } from "node:zlib";
import * as Effect from "effect/Effect";
import * as Schema from "effect/Schema";
import * as NodeServices from "@effect/platform-node/NodeServices";
import { inspectLocalTrace, decodeTraceRetrieval } from "axm.sh/runtime";
import { readContainerReceipts } from "@agentxm/workspace-kernel/locations";
import { workDigest, nativeSerializationWork, automaticCacheMaintenanceWork, periodicMaintenanceWork } from "./repo/benchmarks/observability.ts";
import { compareSummaryDetailWork, observationPairIssues, BinaryManifestSchema, type NativeReceiptSerialization } from "./repo/benchmarks/observability-contract.ts";
import { digest, normalizeObservation, projectComparisonField } from "./repo/benchmarks/observability-process.ts";

const here = path.dirname(fileURLToPath(import.meta.url));
const repo = fs.realpathSync(path.join(here, "repo"));
const expectedMethod = "4fa487526f17031a8ef8f399154a00412e718e93";
const checkpoint = "run-06-remaining-195-2cf3580d3";
const archiveRelative = "benchmarks/evidence/local-observability/captures/" + checkpoint + ".tar.gz";
const archiveSha256 = "7a1ab581216ce913dfaf48818cae637a71bc6caffc5c34ae30342ce33f402603";
const scenarios = ["typed/subagents/install", "typed/knowledge/install", "typed/packs/install", "typed/knowledge/new"];
const check = (condition: boolean, message: string): void => { if (!condition) throw new Error(message); };
const json = (bytes: Uint8Array): unknown => Schema.decodeUnknownSync(Schema.fromJsonString(Schema.Unknown))(Buffer.from(bytes).toString("utf8"));
const canonical = (value: unknown) => JSON.stringify(normalizeObservation(value, []));
const count = Schema.Int.check(Schema.isGreaterThanOrEqualTo(0));
const hash = Schema.String.check(Schema.isPattern(/^[0-9a-f]{64}$/u));
const RecordSchema = Schema.Record(Schema.String, Schema.Unknown);
const at = (value: unknown, fields: ReadonlyArray<string>): unknown => {
  let current = value;
  for (const field of fields) current = Array.isArray(current)
    ? current[Number(field)]
    : Schema.decodeUnknownSync(RecordSchema)(current)[field];
  return current;
};
const CheckSchema = Schema.Struct({
  scenario: Schema.String, mode: Schema.Literals(["disabled", "summary", "detail"]),
  comparisonVerified: Schema.Boolean, comparisonIssues: Schema.Array(Schema.String),
  artifacts: Schema.String, baselineArtifacts: Schema.String,
});
const ReportSchema = Schema.Struct({
  complete: Schema.Literal(false), error: Schema.String,
  baseline: BinaryManifestSchema, candidate: BinaryManifestSchema,
  harnessSha256: hash, dependencyLockSha256: hash,
  fixtureChecks: Schema.Array(CheckSchema),
});
const SampleSchema = Schema.Struct({
  id: Schema.String, phase: Schema.Literal("preflight"), scenario: Schema.String,
  mode: Schema.Literals(["disabled", "summary", "detail"]), subject: Schema.Literals(["baseline", "candidate"]),
  iteration: count, warmup: Schema.Boolean, durationMs: Schema.Number, peakRssBytes: Schema.Number,
  exitCode: count, expectedExitCode: count, inputDigest: hash, stdoutDigest: hash, stderrDigest: hash, postconditionDigest: hash,
  artifacts: Schema.String,
  oracle: Schema.Struct({ verified: Schema.Literal(true), requestCount: count, requestDigest: hash, evidence: Schema.String }),
});
const TraceFields = Schema.Struct({
  complete: Schema.Literal(true), delivery: Schema.Literal("inspected"),
  retainedSpanCount: count, retainedDetailSpanCount: count, summaryGroups: count,
  diagnosticShutdownMillis: Schema.Number, exportFinalizationMillis: Schema.Number,
  traceId: Schema.String, rootSpanId: Schema.String, workDigest: hash, retrievalBytes: count,
});
const AuditSchema = Schema.Struct({
  observation: Schema.String,
  processWindow: Schema.Struct({ startedAtMillis: Schema.Number, endedAtMillis: Schema.Number }),
  observations: Schema.Array(Schema.Struct({
    location: Schema.String,
    classification: Schema.Literals(["new-or-refreshed", "historical-runtime-cleanup-not-poststat-verifiable"]),
    matchesSample: Schema.Boolean, outsideSample: Schema.Array(Schema.String), valid: Schema.Literal(true),
    checks: Schema.Array(Schema.Struct({ field: Schema.String, expected: Schema.optional(Schema.Unknown), observed: Schema.optional(Schema.Unknown), error: Schema.optional(Schema.String), matches: Schema.Boolean })),
  })),
});
const VerificationSchema = Schema.Struct({
  assertions: Schema.Array(Schema.String),
  fileComparisons: Schema.Array(Schema.Struct({ container: Schema.String, path: Schema.String, sha256: hash, reason: Schema.String })),
});

const program = Effect.gen(function* () {
  const [runRoot, output] = yield* Schema.decodeUnknownEffect(Schema.Tuple([Schema.String, Schema.String]))(process.argv.slice(2));
  check(!fs.existsSync(output), "Refuse to overwrite an earlier disposition");
  const revision = execFileSync("git", ["rev-parse", "HEAD"], { cwd: repo, encoding: "utf8" }).trim();
  check(revision === expectedMethod, "Method revision differs from the approved clean checkpoint");
  check(execFileSync("git", ["status", "--porcelain"], { cwd: repo, encoding: "utf8" }).length === 0, "Method checkout is dirty");
  check(digest(fs.readFileSync(path.join(repo, archiveRelative))) === archiveSha256, "Public archive hash mismatch");
  const inputs: Array<{ archiveMember: string; sha256: string; bytes: number; decodedSha256: string; decodedBytes: number }> = [];
  const read = (relative: string) => {
    const member = relative === "report.json" ? "runs/" + checkpoint + "/report.json" : relative.replace(/^samples\/preflight\//u, "reserved/");
    const candidate = path.join(runRoot, member);
    const actual = fs.existsSync(candidate) ? candidate : candidate + ".gz";
    const compressed = fs.readFileSync(actual);
    const decoded = actual.endsWith(".gz") ? gunzipSync(compressed) : compressed;
    const archiveMember = path.relative(runRoot, actual).split(path.sep).join("/");
    if (!inputs.some((entry) => entry.archiveMember === archiveMember)) inputs.push({ archiveMember, sha256: digest(compressed), bytes: compressed.length, decodedSha256: digest(decoded), decodedBytes: decoded.length });
    return decoded;
  };
  const reportBytes = read("report.json");
  const report = yield* Schema.decodeUnknownEffect(ReportSchema)(json(reportBytes));
  const cases: unknown[] = [];
  for (const scenario of scenarios) {
    const checks = report.fixtureChecks.filter((entry) => entry.scenario === scenario);
    check(checks.length === 3, "Missing original mode checks: " + scenario);
    for (const mode of ["disabled", "summary", "detail"]) {
      const own = checks.filter((entry) => entry.mode === mode);
      check(own.length === 1 && own[0] !== undefined, "Duplicate/missing original check: " + scenario + "/" + mode);
      const checkRecord = own[0];
      if (checkRecord === undefined) throw new Error("Unreachable missing check");
      check(checkRecord.comparisonVerified === (mode !== "detail"), "Unexpected original verdict");
      check(canonical(checkRecord.comparisonIssues) === canonical(mode === "detail" ? ["Summary/detail work mismatch: " + scenario] : []), "Original failure is not byte-parity-only");
      const before = yield* Schema.decodeUnknownEffect(SampleSchema)(json(read(checkRecord.baselineArtifacts + "/sample.json")));
      const candidate = yield* Schema.decodeUnknownEffect(SampleSchema)(json(read(checkRecord.artifacts + "/sample.json")));
      check(before.scenario === scenario && candidate.scenario === scenario && candidate.mode === mode, "Sample identity mismatch");
      check(before.exitCode === before.expectedExitCode && candidate.exitCode === candidate.expectedExitCode, "Product exit mismatch");
      check(observationPairIssues(before, candidate).length === 0, "Independent product/input/request comparison mismatch");
    }
    const analyze = Effect.fnUntraced(function* (mode: "summary" | "detail") {
      const directory = "samples/preflight/" + scenario + "/" + mode + "/candidate/validation/0";
      const sample = yield* Schema.decodeUnknownEffect(Schema.Struct({ trace: TraceFields }))(json(read(directory + "/sample.json")));
      const receipt = json(read(directory + "/receipt.json"));
      const receiver = json(read(directory + "/seq/stdout.txt"));
      const expected = json(read(directory + "/expectations.json"));
      const inspected = yield* inspectLocalTrace(receipt, yield* decodeTraceRetrieval(receipt, receiver), { expected });
      const originalInspection = json(read(directory + "/inspection.json"));
      check(canonical(inspected) === canonical(originalInspection), "Current validated inspection does not reproduce retained inspection exactly: " + scenario + "/" + mode);
      const maintenance = yield* automaticCacheMaintenanceWork(inspected);
      const variable = new Set(maintenance);
      const work = inspected.work.filter((row) => !variable.has(row));
      check(workDigest(work) === sample.trace.workDigest, "Original full work digest does not reproduce: " + scenario + "/" + mode);
      const raw = read(directory + "/retained/container-receipts-after/projection-containers.json");
      const projectedBytes = read(directory + "/retained/container-receipts-comparison.json");
      const projected = json(projectedBytes);
      const audit = yield* Schema.decodeUnknownEffect(AuditSchema)(json(read(directory + "/retained/container-receipt-native-observations.json")));
      const verification = yield* Schema.decodeUnknownEffect(VerificationSchema)(json(read(directory + "/semantic-verification.json")));
      const nativeDirectory = path.join(here, "decoded", scenario, mode);
      fs.mkdirSync(nativeDirectory, { recursive: true });
      fs.writeFileSync(path.join(nativeDirectory, "projection-containers.json"), raw, { flag: "wx" });
      // Public schema reader validates the copied artifact; it does not visit the old native targets.
      const document = yield* readContainerReceipts(nativeDirectory).pipe(Effect.provide(NodeServices.layer));
      const identities = [
        ...document.entries.map((entry, index) => ({ location: "entries/" + index, fields: ["entries", String(index), "identity"], identity: entry.identity })),
        ...document.createdDirectories.map((identity, index) => ({ location: "createdDirectories/" + index, fields: ["createdDirectories", String(index)], identity })),
      ];
      check(identities.length === audit.observations.length && new Set(audit.observations.map((row) => row.location)).size === identities.length, "Native audit inventory mismatch");
      let reconstructed: unknown = document;
      const projectedFields: Array<{ path: string; bytes: number; historical: boolean }> = [];
      for (const { location, fields, identity } of identities) {
        const observed = audit.observations.find((entry) => entry.location === location);
        if (observed === undefined) throw new Error("Missing retained native observation");
        check(observed.outsideSample.length === 0, "Old native audit escapes fixture");
        const historical = observed.classification === "historical-runtime-cleanup-not-poststat-verifiable";
        if (historical) {
          check(location.startsWith("createdDirectories/") && identity.target === path.join(identity.ownerRoot, ".axm", "tmp") && identity.entry.birthtime >= audit.processWindow.startedAtMillis && identity.entry.birthtime <= audit.processWindow.endedAtMillis, "Historical scratch binding differs");
          check(observed.checks.some((entry) => entry.field === "entry-present" && entry.observed === false && entry.error === undefined), "No recorded scratch absence");
          check(observed.checks.every((entry) => entry.matches || ["entry", "entry-present", "target-referent", "aliases/0/referent", "aliases/0/link"].includes(entry.field)), "Unapproved native audit mismatch");
        } else check(observed.matchesSample && observed.checks.every((entry) => entry.matches), "Live audit was not independently matched");
        for (const part of [
          { fields: ["owner", "identity"], auditField: "owner", value: identity.owner.identity, historical: false },
          { fields: ["root", "identity"], auditField: "root", value: identity.root.identity, historical: false },
          ...identity.parents.map((parent, index) => ({ fields: ["parents", String(index), "identity"], auditField: "parents/" + index, value: parent.identity, historical: false })),
          { fields: ["entry"], auditField: "entry", value: identity.entry, historical },
        ]) {
          const recorded = observed.checks.find((entry) => entry.field === part.auditField);
          check(recorded !== undefined && canonical(recorded.expected) === canonical(part.value), "Receipt scalar is not bound to retained native audit");
          if (!part.historical) check(recorded?.matches === true && canonical(recorded.observed) === canonical(part.value), "No independently observed live scalar proof");
          for (const field of ["inode", "birthtime"] as const) {
            const position = [...fields, ...part.fields, field];
            const token = "<receipt-" + (part.historical ? "historical-not-poststat-verified" : "live-verified") + "-" + field + ">";
            check(at(projected, position) === token, "Retained comparison marker differs from native proof");
            reconstructed = projectComparisonField(reconstructed, position, part.value[field], token);
            projectedFields.push({ path: position.join("/"), bytes: Buffer.byteLength(JSON.stringify(part.value[field])), historical: part.historical });
          }
        }
      }
      const workspace = identities[0]?.identity.ownerRoot;
      if (workspace === undefined) throw new Error("Missing workspace identity");
      const reconstructedText = JSON.stringify(normalizeObservation(reconstructed, [workspace, path.join(path.dirname(workspace), "home")]));
      check(reconstructedText + "\n" === projectedBytes.toString("utf8"), "Retained projection changes fields beyond validated native scalars/roots");
      const comparison = verification.fileComparisons.filter((entry) => entry.container === "workspace" && entry.path === ".axm/projection-containers.json");
      check(comparison.length === 1 && comparison[0]?.sha256 === digest(reconstructedText), "Original verifier comparison digest differs");
      const proof: NativeReceiptSerialization = {
        path: ".axm/projection-containers.json", rawSha256: digest(raw), rawBytes: raw.length,
        comparisonSha256: digest(reconstructedText),
        projectedFields, projectedFieldCount: projectedFields.length,
        projectedScalarBytes: projectedFields.reduce((sum, field) => sum + field.bytes, 0),
        historicalFieldCount: projectedFields.filter((field) => field.historical).length,
        validation: "native-metadata-and-bounded-cleanup",
      };
      const native = nativeSerializationWork(scenario, work, proof);
      if (native === undefined) throw new Error("No finite shared comparison evidence");
      const trace = { ...sample.trace, periodicMaintenance: periodicMaintenanceWork(inspected.work), automaticCacheMaintenance: maintenance, nativeSerializationWork: native };
      return { trace, artifactPrefix: directory.replace(/^samples\/preflight\//u, "reserved/"), originalAssertions: verification.assertions, originalComparisonReason: comparison[0]?.reason, independentAuditReused: true, freshNativeTargetObservation: false };
    });
    const summary = yield* analyze("summary");
    const detail = yield* analyze("detail");
    const disposition = compareSummaryDetailWork(scenario, summary.trace, detail.trace);
    check(disposition.status === "native-serialization-bytes-inconclusive" && disposition.issues.length === 0, "Shared guard rejected retained case: " + scenario);
    cases.push({ scenario, originalChecks: checks, originalReportRemainsFailed: true, summary, detail, disposition });
  }
  check(digest(fs.readFileSync(path.join(runRoot, "runs", checkpoint, "report.json"))) === digest(reportBytes), "Original report changed during analysis");
  const methodFiles = ["benchmarks/observability.ts", "benchmarks/observability-contract.ts", "benchmarks/observability-fixtures.ts", "benchmarks/observability-process.ts", "pnpm-lock.yaml", "apps/cli/dist/src/machine-output-api.js", "apps/cli/dist/src/cli-runtime/local-trace-inspection.js", "apps/cli/dist/src/cli-runtime/local-trace-policy.js", "apps/cli/dist/src/cli-runtime/local-trace-receipt.js"].map((relative) => ({ path: relative, sha256: digest(fs.readFileSync(path.join(repo, relative))) }));
  const result = {
    schemaVersion: 1, classification: "offline-retained-artifact-analysis", methodRevision: revision,
    script: { path: "consolidate.ts", sha256: digest(fs.readFileSync(fileURLToPath(import.meta.url))) },
    runtime: { name: "bun", version: process.versions.bun }, methodFiles,
    sourceArchive: { path: archiveRelative, sha256: archiveSha256, extractionMapping: { report: "runs/" + checkpoint + "/report.json", payloads: "samples/preflight/<case>/... maps to reserved/<case>/..." } },
    sourceReport: { archiveMember: "runs/" + checkpoint + "/report.json", sha256: digest(reportBytes), complete: report.complete, error: report.error, baseline: report.baseline, candidate: report.candidate, harnessSha256: report.harnessSha256, dependencyLockSha256: report.dependencyLockSha256 },
    limitations: ["No CLI workload, Seq query or fresh native-target observation ran.", "Recorded native metadata was schema-checked and matched to original receipt fields and projection markers; historical scratch entries remain not post-stat verified.", "Original reports remain failed. This sidecar changes neither their bytes nor their verdicts.", "Exact per-invocation totals are retained. Cross-run byte equivalence and complete attribution remain unproven.", "The final-field width envelope is conservative comparison eligibility, not an intermediate-write bound.", "This establishes no repeated timing/RSS qualification."],
    cases, inputs: inputs.sort((a, b) => a.archiveMember.localeCompare(b.archiveMember)),
  };
  fs.writeFileSync(output, JSON.stringify(result, null, 2) + "\n", { flag: "wx" });
  console.log(JSON.stringify({ artifact: output, sha256: digest(fs.readFileSync(output)), cases: cases.length, classification: result.classification }));
});
await Effect.runPromise(program);
